import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestParam String username, @RequestParam String password) {
		User user = userRepository.findByUsername(username);
		if (user != null && new BCryptPasswordEncoder().matches(password, user.getPassword())) {
			return ResponseEntity.ok("Login successful");
		}
		return ResponseEntity.status(401).body("Unauthorized");

	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody RegistrationDto registrationDto) {
		String response = userService.registerUser(registrationDto);
			return ResponseEntity.ok(response);
	}
}
